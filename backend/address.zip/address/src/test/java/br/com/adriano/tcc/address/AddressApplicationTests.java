package br.com.adriano.tcc.address;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AddressApplicationTests {

	@Test
	void contextLoads() {
	}

}
